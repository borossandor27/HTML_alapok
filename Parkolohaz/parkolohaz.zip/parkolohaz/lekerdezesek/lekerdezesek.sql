-- A feladatok megoldására elkészített SQL parancsokat illessze be a feladat sorszáma után!
-- 13. feladat

-- ***
-- 15. feladat

-- ***
-- 16. feladat

-- ***
-- 17. feladat

-- ***
-- 18. feladat

-- ***
